// ======================================================
// NYXORA PDF THEME
// ======================================================

export const NYXORA = {
  logo: "/nyxora-logo.svg",

  company: "NYXORA AI",

  tagline: "Empowering Learning with AI",

  generatedLabel: "AI GENERATED DOCUMENT",

  documentLabel: "NYXORA DOCUMENT",
};

// ======================================================
// PAGE
// ======================================================

export const PAGE = {
  width: 210,
  height: 297,

  marginLeft: 18,
  marginRight: 18,

  marginTop: 20,
  marginBottom: 20,
};

export const CONTENT_WIDTH =
  PAGE.width -
  PAGE.marginLeft -
  PAGE.marginRight;

// ======================================================
// COLORS
// ======================================================

export const COLORS = {
  magenta: [244, 58, 245],

  fuchsia: [217, 70, 239],

  violet: [168, 85, 247],

  primary: [139, 92, 246],

  indigo: [99, 102, 241],

  blue: [59, 130, 246],

  sky: [14, 165, 233],

  cyan: [6, 182, 212],

  darkViolet: [76, 29, 149],

  title: [24, 24, 45],

  heading: [30, 32, 58],

  text: [55, 65, 81],

  secondaryText: [107, 114, 128],

  muted: [107, 114, 128],

  lightText: [148, 163, 184],

  paper: [252, 252, 254],

  glass: [255, 255, 255],

  surface: [248, 249, 255],

  border: [226, 220, 245],

  glassBorder: [232, 235, 247],

  lightPrimary: [247, 244, 255],

  lightBlue: [240, 253, 255],

  lightGreen: [240, 253, 244],

  lightYellow: [255, 251, 235],

  lightRed: [254, 242, 242],

  softFuchsia: [253, 244, 255],

  softCyan: [236, 254, 255],

  success: [34, 197, 94],

  warning: [245, 158, 11],

  danger: [239, 68, 68],

  white: [255, 255, 255],

  black: [0, 0, 0],
};

// ======================================================
// TYPOGRAPHY
// ======================================================

export const FONT = {
  title: 24,

  h1: 18,

  h2: 15,

  h3: 13,

  body: 11,

  caption: 9,

  small: 8,
};

// ======================================================
// SPACING
// ======================================================

export const SPACE = {
  xs: 2,

  sm: 4,

  md: 8,

  lg: 12,

  xl: 18,

  xxl: 24,
};