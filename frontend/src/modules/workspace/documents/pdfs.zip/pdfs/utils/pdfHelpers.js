// ======================================================
// NYXORA PDF HELPERS
// ======================================================

import { PAGE } from "./pdfTheme";

// ======================================================
// SAFE TEXT
// ======================================================

export function safeText(value) {
  if (value === null || value === undefined) {
    return "";
  }

  return String(value);
}

// ======================================================
// FILE NAME
// ======================================================

export function createFileName(title) {
  const cleaned = safeText(title)
    .trim()
    .replace(/[<>:"/\\|?*]+/g, "")
    .replace(/\s+/g, "-")
    .toLowerCase();

  return `${cleaned || "nyxora-document"}.pdf`;
}

// ======================================================
// DEVANAGARI
// ======================================================

export function containsDevanagari(value) {
  return /[\u0900-\u097F]/.test(safeText(value));
}

export function documentContainsDevanagari(documentData = {}) {
  return containsDevanagari(
    [
      documentData.title,
      documentData.type,
      documentData.subject,
      documentData.chapter,
      documentData.content,
    ].join("\n")
  );
}

// ======================================================
// PAGE HELPERS
// ======================================================

export function createPageManager(pdf) {
  let y = PAGE.marginTop;

  function getY() {
    return y;
  }

  function setY(value) {
    y = value;
  }

  function move(space) {
    y += space;
  }

  function ensureSpace(required = 10) {
    if (
      y + required >
      PAGE.height - PAGE.marginBottom
    ) {
      pdf.addPage();
      y = PAGE.marginTop;
    }
  }

  return {
    getY,
    setY,
    move,
    ensureSpace,
  };
}

// ======================================================
// IMAGE LOADER
// ======================================================

export async function loadImage(src) {
  return new Promise((resolve, reject) => {
    const image = new Image();

    image.onload = () => resolve(image);

    image.onerror = reject;

    image.src = src;
  });
}